// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.
window.addEventListener('DOMContentLoaded', () => {
  const replaceText = (selector, text) => {
    const element = document.getElementById(selector)
    if (element) element.innerText = text
  }


const startBtn = document.getElementById('startBtn');
const adb = require('adbkit')
const client = adb.createClient()
var Promise = require('bluebird')

const exec = require('child_process').exec;

startBtn.onclick = e => {
  startBtn.classList.add('is-danger');
  startBtn.innerText = 'Hello World';

  const myShellScript = exec('adb root');
  myShellScript.stdout.on('data', (data)=>{
    console.log(data); 
    // do whatever you want here with data
  });
  myShellScript.stderr.on('data', (data)=>{
    console.error(data);
  });
  

client.listDevices()
  .then(function(devices) {
    return Promise.map(devices, function(device) {
      return client.shell(device.id, 'adb shell root')
        // Use the readAll() utility to read all the content without
        // having to deal with the events. `output` will be a Buffer
        // containing all the output.
        .then(adb.util.readAll)
        .then(function(output) {
          console.log('[%s] %s', device.id, output.toString().trim())
        })
    })
  })
  .then(function() {
    console.log('Done.')
  })
  .catch(function(err) {
    console.error('Something went wrong:', err.stack)
  })
  
};



  for (const type of ['chrome', 'node', 'electron']) {
    replaceText(`${type}-version`, process.versions[type])
  }
})
